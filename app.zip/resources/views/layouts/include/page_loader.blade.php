<div class="page-loader-wrapper">
    <div class="loader">
        <div class="line"></div>
		<div class="line"></div>
		<div class="line"></div>
        <p>Please wait...</p>
        <div class="m-t-30"><img src="{{ asset('assets/images/logo.png')}}" width="48" height="48" alt="Nexa"></div>
    </div>
</div>
