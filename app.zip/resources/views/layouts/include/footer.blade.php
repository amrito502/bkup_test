<div class="row clearfix">
    <div class="col-lg-12">
        <div class="card">
            <div class="body">
                <p class="m-b-0"> ©Admin by <a href="https://reflexit.com.bd/" target="black">Reflex IT</a> </p>
            </div>
        </div>
    </div>
</div>