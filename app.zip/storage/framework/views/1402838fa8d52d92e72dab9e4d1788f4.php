<?php
    $currentRouteName = Route::currentRouteName();

    // echo  $currentRouteName;
?>

<aside id="leftsidebar" class="sidebar">
    
    <div class="menu">
        <ul class="list">

            <?php
                $userRole = Auth::user()->role;
            ?>

            <li class="<?php echo e($currentRouteName == 'dashboard' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('dashboard')); ?>">
                    <img src="<?php echo e(asset('assets/images/icons/dashboard.png')); ?>" alt="">
                    <span>Dashboard</span>
                </a>
            </li>

            <?php if($userRole == '1'): ?>
                <li class="<?php echo e($currentRouteName == 'instructor.index' || $currentRouteName == 'instructor.create' || $currentRouteName == 'instructor.edit' ? 'active' : ''); ?>" : class="">
                    <a href="javascript:void(0);"
                        class="menu-toggle">
                        <img src="<?php echo e(asset('assets/images/icons/teacher.png')); ?>" alt="">
                        <span>Teachers</span>
                    </a>
                    <ul class="ml-menu" <?php echo e($currentRouteName == 'instructor.index' || $currentRouteName == 'instructor.create' || $currentRouteName == 'instructor.edit' ? `style="display: block"` : ''); ?>>
                        <li class="<?php echo e($currentRouteName == 'instructor.index' ? 'active' : ''); ?>"><a href="<?php echo e(route('instructor.index')); ?>">All Teachers</a></li>
                        <li class="<?php echo e($currentRouteName == 'instructor.create' ? 'active' : ''); ?>"><a href="<?php echo e(route('instructor.create')); ?>">Add New</a></li>
                    </ul>
                </li>
            <?php endif; ?>

            <li class="<?php echo e($currentRouteName == 'class.index' || $currentRouteName == 'class.create' || $currentRouteName == 'section.edit' ? 'active' : ''); ?>" : class="">
                <a href="javascript:void(0);" class="menu-toggle">
                    <img src="<?php echo e(asset('assets/images/icons/class.png')); ?>" alt="">
                    <span>Classes</span>
                </a>
                <ul class="ml-menu" <?php echo e($currentRouteName == 'class.index' || $currentRouteName == 'class.create' || $currentRouteName == 'section.edit' ? `style="display: block"` : ''); ?>>
                    <li class="<?php echo e($currentRouteName == 'class.index' ? 'active' : ''); ?>"><a href="<?php echo e(route('class.index')); ?>">All Classes</a></li>
                    <?php if($userRole == '1'): ?>
                    <li class="<?php echo e($currentRouteName == 'class.create' ? 'active' : ''); ?>"><a href="<?php echo e(route('class.create')); ?>">Add New</a></li>
                    <?php endif; ?>
                </ul>
            </li>

            <li class="<?php echo e($currentRouteName == 'section.index' || $currentRouteName == 'section.create' || $currentRouteName == 'section.edit' ? 'active' : ''); ?>">
                <a href="javascript:void(0);" class="menu-toggle">
                    <img src="<?php echo e(asset('assets/images/icons/section.png')); ?>" alt="">
                    <span>Sections</span>
                </a>
                <ul class="ml-menu" <?php echo e($currentRouteName == 'section.index' || $currentRouteName == 'section.create' || $currentRouteName == 'section.edit' ? `style="display: block"` : ''); ?>>
                    <li class="<?php echo e($currentRouteName == 'section.index' ? 'active' : ''); ?>"><a href="<?php echo e(route('section.index')); ?>">All Sections</a></li>
                    <?php if($userRole == '1'): ?>
                    <li class="<?php echo e($currentRouteName == 'section.create' ? 'active' : ''); ?>"><a href="<?php echo e(route('section.create')); ?>">Add New</a></li>
                    <?php endif; ?>
                </ul>
            </li>


            <li class="<?php echo e($currentRouteName == 'subject.index' || $currentRouteName == 'subject.create' || $currentRouteName == 'subject.edit' ? 'active' : ''); ?>">
                <a href="javascript:void(0);" class="menu-toggle">
                    <img src="<?php echo e(asset('assets/images/icons/subject.png')); ?>" alt="">
                    <span>Subjects</span>
                </a>
                <ul class="ml-menu" <?php echo e($currentRouteName == 'subject.index' || $currentRouteName == 'subject.create' || $currentRouteName == 'subject.edit' ? `style="display: block"` : ''); ?>>
                    <li class="<?php echo e($currentRouteName == 'subject.index' ? 'active' : ''); ?>"><a href="<?php echo e(route('subject.index')); ?>">All Subjects</a></li>
                    <li class="<?php echo e($currentRouteName == 'subject.create' ? 'active' : ''); ?>"><a href="<?php echo e(route('subject.create')); ?>">Add New</a></li>
                </ul>
            </li>



            <?php if($userRole == '1' || $userRole == '2'): ?>
                <li class="<?php echo e($currentRouteName == 'student.index' || $currentRouteName == 'student.create' || $currentRouteName == 'student.edit' || $currentRouteName == 'student.view' ? 'active' : ''); ?>">
                    <a href="javascript:void(0);" class="menu-toggle">
                        <img src="<?php echo e(asset('assets/images/icons/students.png')); ?>" alt="">
                        <span>Students</span>
                    </a>
                    <ul class="ml-menu" <?php echo e($currentRouteName == 'student.index' || $currentRouteName == 'student.create' || $currentRouteName == 'student.edit' ? `style="display: block"` : ''); ?>>
                        <li class="<?php echo e($currentRouteName == 'student.index' ? 'active' : ''); ?>"><a href="<?php echo e(route('student.index')); ?>">All Students</a></li>
                        <li class="<?php echo e($currentRouteName == 'student.create' ? 'active' : ''); ?>"><a href="<?php echo e(route('student.create')); ?>">Add New</a></li>
                    </ul>
                </li>
            <?php endif; ?>

            <li class="<?php echo e($currentRouteName == 'attendance.index' || $currentRouteName == 'attendance.show' || $currentRouteName == 'attendance.store' || $currentRouteName == 'attendance.edit' ? 'active' : ''); ?>">
                <a href="javascript:void(0);" class="menu-toggle">
                    <img src="<?php echo e(asset('assets/images/icons/attendance.png')); ?>" alt="">
                    <span>Attendance</span>
                </a>
                <ul class="ml-menu" <?php echo e($currentRouteName == 'attendance.index' || $currentRouteName == 'attendance.show' || $currentRouteName == 'attendance.store' || $currentRouteName == 'attendance.edit' ? `style="display: block"` : ''); ?>>
                    <li class="<?php echo e($currentRouteName == 'attendance.show' || $currentRouteName == 'attendance.edit' ? 'active' : ''); ?>"><a href="<?php echo e(route('attendance.show')); ?>">All Attendance</a></li>
                    <li class="<?php echo e($currentRouteName == 'attendance.index' || $currentRouteName == 'attendance.store' ? 'active' : ''); ?>"><a href="<?php echo e(route('attendance.index')); ?>">Call The Roll</a></li>
                </ul>
            </li>

            <li class="<?php echo e($currentRouteName == 'exam.index' || $currentRouteName == 'exam.create' || $currentRouteName == 'exam.mark' || $currentRouteName == 'exam.edit' || $currentRouteName == 'exam.view'  ? 'active' : ''); ?>"> <a href="javascript:void(0);"
                    class="menu-toggle"><img src="<?php echo e(asset('assets/images/icons/exam.png')); ?>" alt=""><span>Exam</span></a>
                <ul class="ml-menu" <?php echo e($currentRouteName == 'exam.index' || $currentRouteName == 'exam.create' || $currentRouteName == 'exam.edit' || $currentRouteName == 'exam.mark' || $currentRouteName == 'exam.view' ? `style="display: block"` : ''); ?>>
                    <li class="<?php echo e($currentRouteName == 'exam.index' || $currentRouteName == 'exam.edit' || $currentRouteName == 'exam.mark' || $currentRouteName == 'exam.view' ? 'active' : ''); ?>"><a href="<?php echo e(route('exam.index')); ?>">All Exam</a></li>
                    <?php if($userRole == '1'): ?>
                    <li class="<?php echo e($currentRouteName == 'exam.create' ? 'active' : ''); ?>"><a href="<?php echo e(route('exam.create')); ?>">Add New</a></li>
                    <?php endif; ?>
                    
                </ul>
            </li>


            

            <?php if($userRole == '1'): ?>
            <li class="<?php echo e($currentRouteName == 'user.index' || $currentRouteName == 'user.create' || $currentRouteName == 'user.edit' ? 'active' : ''); ?>"> <a href="javascript:void(0);"
                    class="menu-toggle"> <img src="<?php echo e(asset('assets/images/icons/users.png')); ?>" alt=""> <span>Users</span></a>
                <ul class="ml-menu" <?php echo e($currentRouteName == 'user.index' || $currentRouteName == 'user.create' || $currentRouteName == 'user.edit' ? `style="display: block"` : ''); ?>>
                    <li class="<?php echo e($currentRouteName == 'user.index' ? 'active' : ''); ?>"><a href="<?php echo e(route('user.index')); ?>">User Manage</a></li>

                    <li class="<?php echo e($currentRouteName == 'user.create' ? 'active' : ''); ?>"><a href="<?php echo e(route('user.create')); ?>">User add</a></li>

                </ul>
            </li>
            <?php endif; ?>

            <?php if($userRole == '1'): ?>
            <li class="<?php echo e($currentRouteName == 'send-sms-form' || $currentRouteName == 'show-sms-history' ? 'active' : ''); ?>"> <a href="javascript:void(0);"
                    class="menu-toggle"> <img src="<?php echo e(asset('assets/images/icons/users.png')); ?>" alt=""> <span>SMS</span></a>
                <ul class="ml-menu" <?php echo e($currentRouteName == 'send-sms-form' || $currentRouteName == 'show-sms-history' ? `style="display: block"` : ''); ?>>
                    <li class="<?php echo e($currentRouteName == 'send-sms-form' ? 'active' : ''); ?>"><a href="<?php echo e(route('send-sms-form')); ?>">Send SMS</a></li>

                    <li class="<?php echo e($currentRouteName == 'show-sms-history' ? 'active' : ''); ?>"><a href="<?php echo e(route('show-sms-history')); ?>">Show All SMS</a></li>

                </ul>
            </li>
            <?php endif; ?>

            

            

            <!-- <li> <a href="widgets.html"><i class="zmdi zmdi-delicious"></i><span>Widgets</span> </a> </li>
            <li><a href="mail-inbox.html"><i class="zmdi zmdi-email"></i><span>Inbox</span> </a></li>
            <li><a href="blog-dashboard.html"><i class="zmdi zmdi-blogger"></i><span>Blogger</span> </a></li>
            <ul class="ml-menu">
                <li> <a href="ec-dashboard.html">Dashboard</a></li>
                <li> <a href="ec-product.html">Product</a></li>
                <li> <a href="ec-product-List.html">Product List</a></li>
                <li> <a href="ec-product-detail.html">Product detail</a></li>
            </ul>
            </li> -->
        </ul>


    </div>
    <!-- #Menu -->
</aside>
<?php /**PATH /home/siddiqui/bes.alodrivingschool.com/resources/views/layouts/include/left_sidebar.blade.php ENDPATH**/ ?>