<?php $__env->startSection('title', 'Add Class'); ?>
<?php $__env->startSection('description', 'Add your Class.'); ?>
<?php $__env->startSection('breadcrumb01', 'Class'); ?>
<?php $__env->startSection('breadcrumb02', 'Add Class'); ?>
<?php $__env->startSection('app-content'); ?>
    <style>
        .section-card {
            background: #fff;
            min-height: 50px;
            position: relative;
            transition: .5s;
            border-radius: 8px;
            border: none;
            display: flex;
            flex-direction: column;
        }
    </style>

    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="card">
                <div class="header">
                    <h2>Create New Class</h2>
                </div>
                <div class="body">
                    <form id="form_validation" action="<?php echo e(route('class.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group form-float">
                            <div class="form-line">
                                <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>"
                                    class="form-control" required>
                                <?php if($errors->has('name')): ?>
                                    <span class="text-danger"><i class="fas fa-exclamation-triangle"></i>
                                        <?php echo e($errors->first('name')); ?></span>
                                <?php endif; ?>
                                <label class="form-label">Class Name</label>
                            </div>
                        </div>

                        <br>

                        <div class="row clearfix">
                            <div class="col-sm-12">
                                <h2 class="card-inside-title">Select Subject</h2>
                                <div class="demo-checkbox">
                                    

                                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <input type="checkbox" name="subjects[]" id="md_checkbox_<?php echo e($subject->id); ?>" class="chk-col-red" value="<?php echo e($subject->id); ?>"/>
                                        <label for="md_checkbox_<?php echo e($subject->id); ?>"><?php echo e($subject->name); ?></label>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                                <?php if($errors->has('subjects')): ?>
                                    <span class="text-danger"><i class="fas fa-exclamation-triangle"></i>
                                        <?php echo e($errors->first('subjects')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <hr>

                        <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-raised btn-default waves-effect mr-2">Back</a>

                        <button class="btn btn-raised btn-primary waves-effect" type="submit">SUBMIT</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siddiqui/bes.alodrivingschool.com/resources/views/pages/class/create.blade.php ENDPATH**/ ?>