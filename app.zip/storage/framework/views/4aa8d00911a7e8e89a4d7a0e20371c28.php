<?php $__env->startSection('title', 'Edit Section'); ?>
<?php $__env->startSection('description', 'Edit Section .'); ?>
<?php $__env->startSection('breadcrumb01', 'Section'); ?>
<?php $__env->startSection('breadcrumb02', 'Edit Section'); ?>
<?php $__env->startSection('app-content'); ?>
    <style>
        .section-card {
            background: #fff;
            min-height: 50px;
            position: relative;
            transition: .5s;
            border-radius: 8px;
            border: none;
            display: flex;
            flex-direction: column;
        }
    </style>

    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="card">
                <div class="header">
                    <h2>Edit Section</h2>
                </div>
                <div class="body">
                    <form id="form_validation" action="<?php echo e(route('section.update', [$section->id])); ?>" method="post"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group form-float">
                            <div class="form-line">
                                <input type="text" name="name" id="name" value="<?php echo e(@$section->name); ?>"
                                    class="form-control" required placeholder="Section Name">
                                <?php if($errors->has('name')): ?>
                                    <span class="text-danger"><i class="fas fa-exclamation-triangle"></i>
                                        <?php echo e($errors->first('name')); ?></span>
                                <?php endif; ?>

                            </div>
                        </div>



                        <div class="row clearfix">
                            <div class="col-sm-12">
                                <label class="form-label">Select Class</label>
                                <select name="student_classe_id" id="student_classe_id" class="form-control show-tick"
                                    required>
                                    <option value="<?php echo e(@$section->studentClassData->id); ?>">
                                        <?php echo e(@$section->studentClassData->name); ?></option>
                                    <?php $__currentLoopData = $class; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($data->id); ?>"> <?php echo e($data->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('student_classe_id')): ?>
                                    <span class="text-danger"><i class="fas fa-exclamation-triangle"></i>
                                        <?php echo e($errors->first('student_classe_id')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        </br>

                        <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-raised btn-default waves-effect">Back</a>
                        <button class="btn btn-raised btn-primary waves-effect" type="submit">SUBMIT</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siddiqui/bes.alodrivingschool.com/resources/views/pages/sections/edit.blade.php ENDPATH**/ ?>