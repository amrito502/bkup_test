<?php $__env->startSection('title', 'Show SMS History'); ?>
<?php $__env->startSection('description', 'Show All SMS History.'); ?>
<?php $__env->startSection('breadcrumb01', 'Show SMS History'); ?>
<?php $__env->startSection('breadcrumb02', 'Show SMS History'); ?>
<?php $__env->startSection('app-content'); ?>

<div class="row clearfix">
    <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="card">
            <div class="header">
                <h2>Show All SMS History</h2>
            </div>
            <div class="body">
                <table class="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Student Name</th>
                            <th>Class</th>
                            <th>Phone</th>
                            <th style="width: 300px;">SMS</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $sms_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($value->id); ?></td>
                                <td><?php echo e($value->student_name); ?></td>
                                <td><?php echo e($value->class_name); ?></td>
                                <td><?php echo e($value->to); ?></td>
                                <td><?php echo e($value->message); ?></td>
                                <td><?php echo e($value->status_code == 200 ? 'Success' : 'Failed'); ?></td>
                                <td><?php echo e($value->created_at); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <nav aria-label="Page navigation">
                    <?php echo e($sms_history->links('pagination::bootstrap-4')); ?>

                </nav>


            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siddiqui/bes.alodrivingschool.com/resources/views/sms_history.blade.php ENDPATH**/ ?>