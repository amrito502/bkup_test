<?php $__env->startSection('title', 'Exam List'); ?>
<?php $__env->startSection('description', 'Exam list'); ?>
<?php $__env->startSection('breadcrumb01', 'Exam'); ?>
<?php $__env->startSection('breadcrumb02', 'Exam list'); ?>
<?php $__env->startSection('app-content'); ?>

<?php
    $userRole = Auth::user()->role;
?>

    <style>
        .header-flex {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
    </style>
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="card">
                <div class="header header-flex">
                    <h2>Exam List</h2>
                    <?php if($userRole == '1'): ?>
                        <a href="<?php echo e(route('exam.create')); ?>" class="btn btn-success btn-sm ml-auto"><i class="zmdi zmdi-plus"></i>
                            Add Exam</a>
                    <?php endif; ?>
                </div>
                <div class="body table-responsive">
                    <?php if( $exams->count() > 0 ): ?>
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Exam Name</th>
                                <th>Exam Date</th>
                                <th>Exam Marks</th>
                                <th>Teacher Name</th>
                                <th>Class</th>
                                <th style="width: 380px;">Subject List</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($key + 1); ?></th>
                                    <td> <?php echo e($data->name); ?></td>
                                    <td>
                                        <?php
                                            $dateFormate = Carbon\Carbon::parse($data->start_date_time);
                                            echo $dateFormate->format('jS F Y');
                                        ?>
                                    </td>
                                    <td class="text-center"><span class="badge badge-success badge-pill"><?php echo e($data->max_marks); ?></span></td>
                                    <td> <?php echo e($data->teacher->first_name); ?> <?php echo e($data->teacher->last_name); ?></td>
                                    <td>
                                        <?php
                                        $getClassbyID = App\Models\StudentClass::find($data->class_id);
                                        ?>
                                        <?php echo e($getClassbyID->name); ?>

                                    </td>
                                    <td>
                                        <?php
                                            if ($data->subjects == null) {
                                                $getsubjects = [];
                                            }else{
                                                $getsubjects = json_decode($data->subjects);
                                            }
                                        ?>

                                        <?php $__currentLoopData = $getsubjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($subject != null): ?>
                                                <?php
                                                    $subject = App\Models\Subject::where('id', $subject)->first();
                                                ?>
                                                <span class="badge badge-primary"><?php echo e($subject->name); ?></span>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td>
                                        <div class="action__buttons">

                                            <a href="<?php echo e(route('exam.view', [$data->uuid])); ?>" class="badge badge-primary mr-2" title="View">
                                                <i class="fa fa-eye"></i>
                                            </a>

                                            <?php if($userRole == '1'): ?>
                                            <a href="<?php echo e(route('exam.edit', [$data->uuid])); ?>" class="badge badge-info mr-2" title="Edit">
                                                <i class="fa fa-edit"></i>
                                            </a>
                                            <?php endif; ?>

                                            <a href="<?php echo e(route('exam.mark', [$data->uuid])); ?>" class="badge badge-success mr-2" title="Mark">
                                                <i class="fa fa-check"></i>
                                            </a>

                                            <?php if($userRole == '1'): ?>
                                            <a class="badge badge-danger delete" onclick="return confirm('Are you sure? You want to delete')"
                                                href="<?php echo e(route('exam.delete', $data->uuid)); ?>" title="Delete">
                                                <i class="fa fa-trash"></i>
                                            </a>
                                            <?php endif; ?>

                                        </div>

                                        
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php else: ?>
                    <div class="alert alert-warning text-center"> <i class="zmdi zmdi-alert-triangle"></i> No Data Found</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siddiqui/bes.alodrivingschool.com/resources/views/pages/exam/index.blade.php ENDPATH**/ ?>