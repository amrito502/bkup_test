<?php $__env->startSection('title', 'Add Exam'); ?>
<?php $__env->startSection('description', 'Add your Exam.'); ?>
<?php $__env->startSection('breadcrumb01', 'Exam'); ?>
<?php $__env->startSection('breadcrumb02', 'Add Exam'); ?>
<?php $__env->startSection('app-content'); ?>
    <style>
        .section-card {
            background: #fff;
            min-height: 50px;
            position: relative;
            transition: .5s;
            border-radius: 8px;
            border: none;
            display: flex;
            flex-direction: column;
        }

        .header-flex {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
    </style>

    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="card">
                <div class="header header-flex">
                    <h2>Create New Exam</h2>
                    <a href="<?php echo e(route('exam.index')); ?>" class="btn btn-success btn-sm ml-auto"><i class="fa fa-file-text mr-2" style="font-size: 14px; top: 0px;"></i> Exam List</a>
                </div>
                <div class="body">
                    <form id="form_validation" action="<?php echo e(route('exam.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <h2 class="card-inside-title">Exam Name</h2>
                                        <input type="text" name="name" id="name" value="<?php echo e(@$exams->name); ?>"
                                            class="form-control" required placeholder="Exam Name">
                                        <?php if($errors->has('name')): ?>
                                            <span class="text-danger"><i class="fas fa-exclamation-triangle"></i>
                                                <?php echo e($errors->first('name')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <h2 class="card-inside-title">Exam Date</h2>
                                        <input type="date" class="form-control date" name="start_date_time" id="start_date_time"
                                            value="<?php echo e(old('start_date_time')); ?>" placeholder="Exam Date: DD/MM/YYYY" required>
                                        <?php if($errors->has('name')): ?>
                                            <span class="text-danger"><i class="fas fa-exclamation-triangle"></i>
                                                <?php echo e($errors->first('start_date_time')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4">
                                <?php if(Auth::user()->instructor == null && Auth::user()->student == null): ?>
                                    <div class="form-group form-float">
                                        <div class="row clearfix">
                                            <div class="col-sm-12">
                                                <h2 class="card-inside-title">Select Teacher</h2>
                                                <select name="teacher_id" id="teacher_id" class="form-control show-tick">
                                                    <option value="">Select Teacher</option>
                                                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($data->user_id); ?>"> <?php echo e($data->first_name); ?>

                                                            <?php echo e($data->last_name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <h2 class="card-inside-title">Max Marks</h2>
                                        <input type="number" name="max_marks" id="max_marks" value="<?php echo e(@$exams->name); ?>"
                                            class="form-control" required placeholder="Enter Max Marks">
                                        <?php if($errors->has('max_marks')): ?>
                                            <span class="text-danger"><i class="fas fa-exclamation-triangle"></i>
                                                <?php echo e($errors->first('max_marks')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group form-float">
                                    <h2 class="card-inside-title">Select Class</h2>
                                    <select name="class_id" id="class_id" class="form-control show-tick">
                                        <option value="">Select Class</option>
                                        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($data->id); ?>"
                                                <?php echo e(old('name') == $data->name ? 'selected' : ''); ?>> <?php echo e($data->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('name')): ?>
                                        <span class="text-danger"><i class="fas fa-exclamation-triangle"></i>
                                            <?php echo e($errors->first('name')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="form-group form-float">
                            <div class="row clearfix">
                                <div class="col-sm-12">
                                    <h2 class="card-inside-title">Select Subject</h2>
                                    <div class="demo-checkbox" id="subjectList">
                                        <p class="text-info">Please select class first to add subject</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        </br>

                        <button class="btn btn-raised btn-primary waves-effect" type="submit">SUBMIT</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        var classSelect = document.getElementById('class_id');
        var subjectList = document.getElementById('subjectList');

        classSelect.addEventListener('change', function () {
            var classId = this.value;
            // Fetch subjects based on selected class using AJAX
            fetch( '<?php echo e(route("get-subjects")); ?>?class_id=' + classId)
                .then(response => response.json())
                .then(data => {

                    // console.log(data);

                    // Clear existing subjects
                    subjectList.innerHTML = '';

                    data['subjects'].forEach(subject => {
                        var checkbox = document.createElement('input');
                        checkbox.type = 'checkbox';
                        checkbox.name = 'subjects[]'; // Set the name attribute for submission
                        checkbox.value = subject.id; // Set the value attribute for submission
                        checkbox.id = 'md_checkbox_' + subject.id;
                        checkbox.className = 'chk-col-red';
                        checkbox.checked = true;

                        var label = document.createElement('label');
                        label.htmlFor = 'md_checkbox_' + subject.id;
                        label.textContent = subject.name;

                        subjectList.appendChild(checkbox);
                        subjectList.appendChild(label);
                    });
                })
                .catch(error => console.error('Error fetching subjects:', error));
        });
    });
</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siddiqui/bes.alodrivingschool.com/resources/views/pages/exam/create.blade.php ENDPATH**/ ?>