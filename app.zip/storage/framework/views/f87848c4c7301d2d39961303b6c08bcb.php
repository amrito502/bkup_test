<?php $__env->startSection('title', 'Add User'); ?>
<?php $__env->startSection('description', 'Add your own User to access the application.'); ?>
<?php $__env->startSection('breadcrumb01', 'User'); ?>
<?php $__env->startSection('breadcrumb02', 'Add User'); ?>
<?php $__env->startSection('app-content'); ?>
    <style>
        .section-card {
            background: #fff;
            min-height: 50px;
            position: relative;
            transition: .5s;
            border-radius: 8px;
            border: none;
            display: flex;
            flex-direction: column;
        }
    </style>

    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="card">
                <div class="header">
                    <h2>Create new user</h2>
                    
                </div>
                <div class="body">
                    <form id="form_validation" action="<?php echo e(route('user.store')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                        <div class="form-group form-float">
                            <div class="form-line">
                                <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>"
                                    class="form-control" required>
                                <?php if($errors->has('name')): ?>
                                    <span class="text-danger"><i class="fas fa-exclamation-triangle"></i>
                                        <?php echo e($errors->first('name')); ?></span>
                                <?php endif; ?>
                                <label class="form-label">Name</label>
                            </div>
                        </div>
                        <div class="form-group form-float">
                            <div class="form-line">
                                <input type="text" name="email" id="email" value="<?php echo e(old('email')); ?>"
                                    class="form-control" required>
                                <?php if($errors->has('email')): ?>
                                    <span class="text-danger"><i class="fas fa-exclamation-triangle"></i>
                                        <?php echo e($errors->first('email')); ?></span>
                                <?php endif; ?>
                                <label class="form-label">Email</label>
                            </div>
                        </div>
                        <div class="form-group form-float">
                            <div class="form-line">
                                <input type="text" name="phone_number" id="phone_number" value="<?php echo e(old('phone_number')); ?>"
                                    class="form-control" required>
                                <?php if($errors->has('phone_number')): ?>
                                    <span class="text-danger"><i class="fas fa-exclamation-triangle"></i>
                                        <?php echo e($errors->first('phone_number')); ?></span>
                                <?php endif; ?>
                                <label class="form-label">Phone</label>
                            </div>
                        </div>
                        <div class="form-group form-float">
                            <div class="form-line">
                                <input type="text" name="address" id="address" value="<?php echo e(old('address')); ?>"
                                    class="form-control" required>
                                <?php if($errors->has('address')): ?>
                                    <span class="text-danger"><i class="fas fa-exclamation-triangle"></i>
                                        <?php echo e($errors->first('address')); ?></span>
                                <?php endif; ?>
                                <label class="form-label">Address</label>
                            </div>
                        </div>
               
                        <div class="row clearfix">
                            <div class="col-sm-12">
                                <label class="form-label">Select Role</label>
                                <select  name="role_name" id="role_name" class="form-control show-tick">
                                 <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($role->name); ?>" <?php echo e(old('role_name') == $role->name ? 'selected' : ''); ?>> <?php echo e($role->name); ?></option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                 <?php if($errors->has('role_name')): ?>
                                    <span class="text-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo e($errors->first('role_name')); ?></span>
                                <?php endif; ?>
                            </div>
                            
                        </div>
                        <div class="form-group form-float">
                            <div class="form-line">
                                <input type="password" name="password" id="name" value="<?php echo e(old('password')); ?>"
                                    class="form-control" required>
                                <?php if($errors->has('password')): ?>
                                    <span class="text-danger"><i class="fas fa-exclamation-triangle"></i>
                                        <?php echo e($errors->first('password')); ?></span>
                                <?php endif; ?>
                                <label class="form-label">Password</label>
                            </div>
                        </div>
                       
                       
                        <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-raised btn-default waves-effect">Back</a>
                        <button class="btn btn-raised btn-primary waves-effect" type="submit">SUBMIT</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siddiqui/bes.alodrivingschool.com/resources/views/pages/user/create.blade.php ENDPATH**/ ?>