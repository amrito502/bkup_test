<?php $__env->startSection('title', 'Assgin'); ?>
<?php $__env->startSection('description', 'Assgin.'); ?>
<?php $__env->startSection('breadcrumb01', 'Assgin'); ?>
<?php $__env->startSection('breadcrumb02', 'Assgin'); ?>
<?php $__env->startSection('app-content'); ?>
<div class="row clearfix">
    <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="card">
            <div class="header">
                <h2>Send SMS</h2>
            </div>
            <div class="body">
                <form id="form_validation" action="<?php echo e(route('sendStudentSms')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="row clearfix">
                        <div class="col-lg-4 col-md-6">
                            <div class="form-group">
                                <div class="form-line">
                                    <label class="form-label">Select Class</label>
                                    <select name="class_id" id="class_id" class="form-control show-tick" required>
                                        <option value="">Select Class</option>
                                        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($data->id); ?>"
                                                <?php echo e(old('name') == $data->name ? 'selected' : ''); ?>>
                                                <?php echo e($data->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('name')): ?>
                                        <span class="text-danger"><i class="fas fa-exclamation-triangle"></i>
                                            <?php echo e($errors->first('name')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-6">
                            <div class="form-group">
                                <div class="form-line">
                                    <select name="section_id" id="section_id" class="form-control show-tick"
                                        required>
                                        <option value="">Select Section</option>

                                    </select>
                                    <?php if($errors->has('name')): ?>
                                        <span class="text-danger"><i class="fas fa-exclamation-triangle"></i>
                                            <?php echo e($errors->first('name')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-6">
                            <div class="form-group">
                                <div class="form-line">
                                    <select name="shift" id="shift" class="form-control show-tick">
                                        <option value="">Select Shift</option>
                                        <option value="Morning" <?php echo e(old('shift') == 'Morning' ? 'selected' : ''); ?>>Morning
                                        </option>
                                        <option value="Day" <?php echo e(old('shift') == 'Day' ? 'selected' : ''); ?>>Day
                                        </option>
                                    </select>
                                    <?php if($errors->has('shift')): ?>
                                        <span class="text-danger"><i class="fas fa-exclamation-triangle"></i>
                                            <?php echo e($errors->first('shift')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row clearfix">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <div class="form-line">
                                    <label class="form-label">Message</label>
                                    <textarea id="message" name="message" class="form-control" style="height:150px"></textarea>
                                    <?php if($errors->has('message')): ?>
                                        <span class="text-danger"><i class="fa fa-exclamation-triangle"></i> <?php echo e($errors->first('message')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    </br>
                    <a href="<?php echo e(route('assgin.index')); ?>" class="btn btn-raised btn-default waves-effect">Back</a>
                    <button class="btn btn-raised btn-primary waves-effect" type="submit">SUBMIT</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<!-- Include jQuery if not already included -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- Include Bootstrap and Bootstrap-select if not already included -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.18/css/bootstrap-select.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.18/js/bootstrap-select.min.js"></script>

<script type="text/javascript">
    $(document).ready(function() {
        $('#class_id').change(function() {
            var classId = $(this).val();

            // alert(classId);

            if(classId) {
                $.ajax({
                    url: '<?php echo e(url("/get-sections-by-class")); ?>/' + classId,
                    type: "GET",
                    dataType: "json",
                    success: function(data) {
                        $('#section_id').empty();

                        //console.log(data);

                        $.each(data, function(key, value) {

                            console.log(key, value);

                            $('#section_id').append('<option value="'+ key +'">'+ value +'</option>');
                        });

                        $('#section_id').selectpicker('refresh');

                    }
                });
            } else {
                $('#section_id').empty();
                $('#section_id').selectpicker('refresh');
            }
        });
    });
</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siddiqui/bes.alodrivingschool.com/resources/views/send_sms.blade.php ENDPATH**/ ?>