<?php $__env->startSection('title', 'Section List'); ?>
<?php $__env->startSection('description', 'Section list'); ?>
<?php $__env->startSection('breadcrumb01', 'Section'); ?>
<?php $__env->startSection('breadcrumb02', 'Section list'); ?>
<?php $__env->startSection('app-content'); ?>

<?php
    $userRole = Auth::user()->role;
?>

    <style>
        .header-flex {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
    </style>
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="card">
                <div class="header header-flex">
                    <h2>Section List</h2>
                    <?php if($userRole == '1'): ?>
                    <a href="<?php echo e(route('section.create')); ?>" class="btn btn-success btn-sm ml-auto"><i class="zmdi zmdi-plus"></i>
                        Add Section</a>
                    <?php endif; ?>
                </div>
                <div class="body table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Section Name</th>
                                <th>Class Name</th>
                                <?php if($userRole == '1'): ?>
                                <th>Action</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($key + 1); ?></th>
                                    <td> <?php echo e($data->name); ?></td>
                                    <td> <?php echo e($data->studentClassData->name); ?></td>
                                    <?php if($userRole == '1'): ?>
                                    <td>
                                        <div class="action__buttons">

                                            <a href="<?php echo e(route('section.edit', [$data->id])); ?>" class="badge badge-info mr-2">
                                                <i class="fa fa-edit"></i>
                                            </a>


                                            <a class="badge badge-danger delete" onclick="return confirm('Are you sure? You want to delete')"
                                                href="<?php echo e(route('section.delete', $data->id)); ?>"><i class="fa fa-trash"></i></a>

                                        </div>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siddiqui/bes.alodrivingschool.com/resources/views/pages/sections/index.blade.php ENDPATH**/ ?>