<?php $__env->startSection('title', 'User List'); ?>
<?php $__env->startSection('description', 'User list'); ?>
<?php $__env->startSection('breadcrumb01', 'User'); ?>
<?php $__env->startSection('breadcrumb02', 'User list'); ?>
<?php $__env->startSection('app-content'); ?>
    <style>
        .header-flex {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
    </style>
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="card">
                <div class="header header-flex">
                    <h2>User List</h2>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add_user')): ?>
                    <a href="<?php echo e(route('user.create')); ?>" class="btn btn-success btn-sm ml-auto"><i class="zmdi zmdi-plus"></i>
                        Add User</a>
                    <?php endif; ?>
                </div>
                <div class="body table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Address</th>
                                <th>Phone</th>
                                <th>Role</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($key + 1); ?></th>
                                    <td> <?php echo e($user->name); ?></td>
                                    <td> <?php echo e($user->email); ?></td>
                                    <td> <?php echo e($user->address); ?></td>
                                    <td> <?php echo e($user->phone_number); ?></td>
                                    <td>  <?php if(count($user->getRoleNames()) > 0): ?> <?php echo e($user->getRoleNames()[0]); ?><?php endif; ?> </td>
                                    <td>
                                        <div class="action__buttons">
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_user')): ?>
                                            <a href="<?php echo e(route('user.edit', [$user->id])); ?>" class="btn-action">
                                                <img src="<?php echo e(asset('admin/images/icons/edit-2.svg')); ?>" alt="edit">
                                            </a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete_user')): ?>
                                            <a class="btn-action delete" onclick="return confirm('Are you sure? You want to delete')"
                                                href="<?php echo e(route('user.delete', $user->id)); ?>"> <img
                                                    src="<?php echo e(asset('admin/images/icons/trash-2.svg')); ?>" alt="trash"></a>
                                        <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siddiqui/bes.alodrivingschool.com/resources/views/pages/user/index.blade.php ENDPATH**/ ?>