<?php $__env->startSection('title', 'Student Mark'); ?>
<?php $__env->startSection('description', 'Student Mark'); ?>
<?php $__env->startSection('breadcrumb01', 'Student'); ?>
<?php $__env->startSection('breadcrumb02', 'Student Mark'); ?>
<?php $__env->startSection('app-content'); ?>
    <!-- Page content area start -->
    <div class="row clearfix">
        <div class="col-lg-12">
            <div class="card">
                <div class="header">
                    <h2>Student Mark</h2>
                    
                </div>
                <div class="body">
                    
                    <div class="mt-40"></div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="table-responsive">
                                <table id="mainTable" class="table table-striped" style="cursor: pointer;">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Exam Name</th>
                                            <th>Subject</th>
                                            <th>Fianl Mark</th>
                                            
                                        </tr>
                                    </thead>

                                    
                                    <tbody>
                                        <?php $__currentLoopData = $exam_marks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(!empty($item->exam)): ?>
                                        <tr>
                                            <td><?php echo e($key+1); ?></td>
                                            <td><?php echo e($item->exam->name); ?></td>
                                            <td><?php echo e($item->exam->subjects->name); ?></td>
                                            <td><?php echo e(doubleval($item->mark)); ?></td>
                                           
                                        </tr>
                                            
                                        <?php endif; ?>
                                        
                                       
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <hr>
                   
                    
                </div>
            </div>
        </div>
    </div>
    <!-- Page content area end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siddiqui/bes.alodrivingschool.com/resources/views/pages/mark/index.blade.php ENDPATH**/ ?>