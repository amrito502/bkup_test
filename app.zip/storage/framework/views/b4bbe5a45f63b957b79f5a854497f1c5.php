<?php $__env->startSection('title', 'Student List'); ?>
<?php $__env->startSection('description', 'Student list'); ?>
<?php $__env->startSection('breadcrumb01', 'Student'); ?>
<?php $__env->startSection('breadcrumb02', 'Student list'); ?>
<?php $__env->startSection('app-content'); ?>

<?php
    $userRole = Auth::user()->role;
    $class_id = request()->get('class_id') ?: 1;
    $section_id = request()->get('section_id') ?: 1;
    $search = request()->get('search') ?: '';
    $get_shift = request()->get('shift') ?: 'Day';
?>
    <style>
        .header-flex {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        body #SearchForm {
            display: flex;
            flex-direction: row;
            align-items: end;
        }
    </style>
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12">
            
            <div class="card">
                <div class="header ">
                    <div class="top d-flex justify-content-between align-items-center">
                        <h2>Student List</h2>

                        <a href="<?php echo e(route('student.create')); ?>" class="btn btn-success btn-sm ml-auto">
                            <i class="zmdi zmdi-plus"></i> Add Student
                        </a>

                    </div>

                    <form id="SearchForm" method="get" action="<?php echo e(route('student.index')); ?>">
                        <?php echo csrf_field(); ?>

                        <input type="text" id="search" style="width: 285px;" class="form-control mb-0 mr-3" placeholder="Search Student" name="search" value="<?php echo e($search); ?>">

                        <select name="class_id" id="class_id" class="form-control show-tick mr-3">
                            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($class->id); ?>" <?php echo e($class_id == $class->id ? 'selected' : ''); ?>><?php echo e($class->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <select id="section_id" name="section_id" class="form-control show-tick mr-3">
                            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($section->id ? $section->id : 1); ?>" <?php echo e($section_id == $section->id ? 'selected' : ''); ?>><?php echo e($section->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <select name="shift" id="shift" class="form-control show-tick mr-3">
                            <option value="Day" <?php echo e($get_shift == 'Day' ? 'selected' : ''); ?>>Day</option>
                            <option value="Morning" <?php echo e($get_shift == 'Morning' ? 'selected' : ''); ?>>Morning</option>
                        </select>
                        <button type="submit" class="btn btn-info btn-sm ml-auto"> <i class="zmdi zmdi-filter-list"></i> FILTER</button>
                    </form>

                </div>
                <div class="body table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Address</th>
                                <th>Phone</th>
                                <th>Class</th>
                                <th>Section</th>
                                <th>Shift</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($key + 1); ?></th>
                                    <td> <?php echo e($users->first_name); ?> <?php echo e($users->last_name); ?></td>
                                    <td> <?php echo e($users->user->email); ?></td>
                                    <td> <?php echo e($users->address == null ? 'N/L' : $users->address); ?></td>
                                    <td> <?php echo e($users->phone_number); ?></td>
                                    <td> <?php echo e($users->assign->studentClass->name); ?></td>

                                    <td> <?php echo e($users->assign->section->name); ?></td>
                                    <td><?php echo e($users->assign->shift); ?></td>
                                    <td>
                                        <div class="action__buttons">
                                            <a href="<?php echo e(route('student.edit', [$users->uuid])); ?>" class="badge badge-info mr-2" title="Edit">
                                                <i class="zmdi zmdi-edit"></i>
                                            </a>
                                            <?php if($userRole == '1'): ?>
                                            <a class="badge badge-danger delete mr-2"
                                                onclick="return confirm('Are you sure? You want to delete')"
                                                href="<?php echo e(route('student.delete', $users->uuid)); ?>" title="Delete">

                                                <i class="fa fa-trash"></i>
                                            </a>
                                            <?php endif; ?>
                                            <a href="<?php echo e(route('student.view', [$users->uuid])); ?>" class="badge badge-success" title="View">
                                                <i class="zmdi zmdi-eye"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const searchInput = document.getElementById('search');
        const tableRows = document.querySelectorAll('.table tbody tr');

        searchInput.addEventListener('input', function () {
            const searchQuery = this.value.trim().toLowerCase();

            tableRows.forEach(function (row) {
                let isMatch = false;

                row.querySelectorAll('td').forEach(function (cell) {
                    const cellData = cell.textContent.trim().toLowerCase();
                    if (cellData.includes(searchQuery)) {
                        isMatch = true;
                    }
                });

                if (isMatch) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    });
</script>

<!-- Include jQuery if not already included -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- Include Bootstrap and Bootstrap-select if not already included -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.18/css/bootstrap-select.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.18/js/bootstrap-select.min.js"></script>

<script type="text/javascript">
    $(document).ready(function() {

        var selectedClassID = <?php echo $class_id; ?>;

        // Function to fetch sections based on class ID
        function fetchSections(classId) {
            $.ajax({
                url: '<?php echo e(url("/get-sections-by-class")); ?>/' + classId,
                type: "GET",
                dataType: "json",
                success: function(data) {
                    updateSectionOptions(data);
                },
                error: function() {
                    console.error('Failed to fetch sections.');
                }
            });
        }

        // Function to update section options
        function updateSectionOptions(data) {
            $('#section_id').empty();

            $.each(data, function(key, value) {
                $('#section_id').append('<option value="' + key + '">' + value + '</option>');
            });

            $('#section_id').selectpicker('refresh');
        }

        // Initial fetch if a class ID is selected
        if (selectedClassID) {
            $('#class_id').val(selectedClassID);
            fetchSections(selectedClassID);
        } else {
            updateSectionOptions([]);
        }

        // Event listener for class ID change
        $('#class_id').change(function() {
            var classId = $(this).val();

            if (classId) {
                fetchSections(classId);
            } else {
                updateSectionOptions([]);
            }
        });
    });
</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siddiqui/bes.alodrivingschool.com/resources/views/pages/student/index.blade.php ENDPATH**/ ?>