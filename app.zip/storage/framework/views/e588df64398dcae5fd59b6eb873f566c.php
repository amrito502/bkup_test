<?php $__env->startSection('title', 'Teacher Edit'); ?>
<?php $__env->startSection('description', 'Teacher Edit'); ?>
<?php $__env->startSection('breadcrumb01', 'Teacher'); ?>
<?php $__env->startSection('breadcrumb02', 'Teacher Edit'); ?>
<?php $__env->startSection('app-content'); ?>

    <style>
        .header-flex {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
    </style>
    <!-- Input Group -->
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="card">
                <div class="header">
                    <h2> Teacher Edit </h2>
                    <ul class="header-dropdown m-r--5">
                        <li class="dropdown"> <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown"
                                role="button" aria-haspopup="true" aria-expanded="false"> <i
                                    class="zmdi zmdi-more-vert"></i> </a>
                            <ul class="dropdown-menu pull-right">
                                <li><a href="javascript:void(0);">Action</a></li>
                                <li><a href="javascript:void(0);">Another action</a></li>
                                <li><a href="javascript:void(0);">Something else here</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>

                <div class="body">
                    <form id="form_validation" action="<?php echo e(route('instructor.update', $instructor->uuid)); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row clearfix">
                            <div class="col-lg-4 col-md-6">
                                <div class="form-group">
                                    <div class="form-line">
                                    <input type="text" name="first_name" value="<?php echo e($instructor->first_name); ?>" placeholder="First name" class="form-control" required>
                                        <?php if($errors->has('first_name')): ?>
                                          <span class="text-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo e($errors->first('first_name')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="last_name" value="<?php echo e($instructor->last_name); ?>" placeholder="Last name" class="form-control" required>
                                        <?php if($errors->has('last_name')): ?>
                                            <span class="text-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo e($errors->first('last_name')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-6">
                                <div class="form-group">
                                    <div class="form-line">
                                        <!-- <small>Asign role</small> -->
                                            <select  name="gender" id="gender" class="form-control show-tick" required>
                                            <option value="">Select option</option>
                                            <option value="Male" <?php echo e($instructor->gender == 'Male' ? 'selected' : ''); ?> >Male</option>
                                            <option value="Female" <?php echo e($instructor->gender == 'Female' ? 'selected' : ''); ?> >Female</option>
                                            <option value="Others" <?php echo e($instructor->gender == 'Others' ? 'selected' : ''); ?> >Others</option>
                                            </select>
                                            <?php if($errors->has('gender')): ?>
                                                <span class="text-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo e($errors->first('gender')); ?></span>
                                            <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="email" name="email" value="<?php echo e($user->email); ?>" placeholder="Email" class="form-control" required>
                                        <?php if($errors->has('email')): ?>
                                            <span class="text-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo e($errors->first('email')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-lg-4 col-md-6">
                                <div class="form-group">
                                    <div class="form-line">
                                    <input type="text" name="professional_title" value="<?php echo e($instructor->professional_title); ?>" placeholder="Designation" class="form-control"
                                           required>
                                    <?php if($errors->has('professional_title')): ?>
                                        <span class="text-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo e($errors->first('professional_title')); ?></span>
                                    <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6">
                                <div class="form-group">
                                    <div class="form-line">
                                    <input type="text" name="phone_number" value="<?php echo e($user->phone_number); ?>" placeholder="Phone number" class="form-control">
                                    <?php if($errors->has('phone_number')): ?>
                                        <span class="text-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo e($errors->first('phone_number')); ?></span>
                                    <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6">
                                <div class="form-group">
                                    <div class="form-line">
                                    <input type="text" name="address" value="<?php echo e($instructor->address); ?>" placeholder="Address" class="form-control"
                                           required>
                                    <?php if($errors->has('address')): ?>
                                        <span class="text-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo e($errors->first('address')); ?></span>
                                    <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-lg-4 col-md-6">
                                <div class="form-group">
                                    <div class="form-line">
                                        <select  name="class_id" id="class_id" class="form-control show-tick" required>
                                            <option value="<?php echo e($user->assign->studentClass->id); ?>"><?php echo e($user->assign->studentClass->name); ?></option>
                                         <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($data->id); ?>" <?php echo e(old('name') == $data->name ? 'selected' : ''); ?>> <?php echo e($data->name); ?></option>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                         <?php if($errors->has('name')): ?>
                                            <span class="text-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo e($errors->first('name')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-6">
                                <div class="form-group">
                                    <div class="form-line">

                                        <select  name="section_id" id="section_id" class="form-control show-tick" required>
                                            <option value="<?php echo e($user->assign->section->id); ?>"><?php echo e($user->assign->section->name); ?></option>
                                            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($data->id); ?>" <?php echo e(old('name') == $data->name ? 'selected' : ''); ?>> <?php echo e($data->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                           </select>
                                            <?php if($errors->has('name')): ?>
                                               <span class="text-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo e($errors->first('name')); ?></span>
                                           <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <br/>
                        <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-raised btn-default waves-effect">Back</a>
                        <button class="btn btn-raised btn-primary waves-effect" type="submit">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- #END# Input Group -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/custom/image-preview.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('admin/js/custom/image-preview.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/custom/admin-profile.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siddiqui/bes.alodrivingschool.com/resources/views/pages/instructor/edit.blade.php ENDPATH**/ ?>