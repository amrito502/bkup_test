<?php $__env->startSection('title', 'Edit Attendance'); ?>
<?php $__env->startSection('description', 'Edit Attendance'); ?>
<?php $__env->startSection('breadcrumb01', 'Attendance'); ?>
<?php $__env->startSection('breadcrumb02', 'Edit Attendance'); ?>
<?php $__env->startSection('app-content'); ?>
    <style>
        .section-card {
            background: #fff;
            min-height: 50px;
            position: relative;
            transition: .5s;
            border-radius: 8px;
            border: none;
            display: flex;
            flex-direction: column;
        }
    </style>

    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="card">
                <div class="header">
                    <h2>Edit Attendance</h2>
                </div>

                <form id="form_validation" action="<?php echo e(route('attendance.update', ['6019f554-3dcf-4180-950a-a68266d47d2a'])); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="body table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Student Name</th>
                                    <th>Roll No</th>
                                    <th>Class</th>
                                    <th>Section</th>
                                    <th>Shift</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item->students !=null): ?>
                                    <tr>
                                        <th scope="row"><?php echo e($key+1); ?></th>
                                        <td><?php echo e($item->students->first_name); ?> <?php echo e($item->students->last_name); ?></td>
                                        <td><?php echo e($item->students->id); ?></td>
                                        <td><?php echo e($item->studentClass->name); ?></td>
                                        <td><?php echo e($item->studentClass->sections->name); ?></td>
                                        <td><?php echo e($item->shift); ?></td>
                                        <td>
                                            <input type="hidden" name="date" value="<?php echo e($item->date); ?>">

                                            <div class="d-flex">
                                                <div class="form-check mb-0 d-flex align-items-center mr-2">
                                                    <input class="form-check-input attendence-checkbox" type="checkbox" name="attendence[<?php echo e($item->student_id); ?>]" id="attendence<?php echo e($item->id); ?>" value="<?php echo e($item->student_id); ?>" data-row-id="<?php echo e($key); ?>" <?php echo e($item->attent == 1 ? 'checked' : ''); ?>>
                                                    <label class="form-check-label m-lg-1 mb-0 color-heading" for="attendence<?php echo e($item->id); ?>" style="color: green">
                                                        Present
                                                    </label>
                                                </div>
                                                <div class="form-check mb-0 d-flex align-items-center mr-2">
                                                    <input class="form-check-input attendence-absent-checkbox" type="checkbox" name="attendence_absent[<?php echo e($item->student_id); ?>]" id="attendence_absent<?php echo e($item->id); ?>" value="<?php echo e($item->student_id); ?>" data-row-id="<?php echo e($key); ?>" <?php echo e($item->attent == 0 ? 'checked' : ''); ?>>
                                                    <label class="form-check-label m-lg-1 mb-0 color-heading" for="attendence_absent<?php echo e($item->id); ?>" style="color: red">
                                                        Absent
                                                    </label>
                                                </div>
                                                <div class="form-check mb-0 d-flex align-items-center">
                                                    <input class="form-check-input attendence-absent-checkbox" type="checkbox" name="attendence_delay[<?php echo e($item->student_id); ?>]" id="attendence_delay<?php echo e($item->id); ?>" value="<?php echo e($item->student_id); ?>" data-row-id="<?php echo e($key); ?>" <?php echo e($item->attent == 2 ? 'checked' : ''); ?> >
                                                    <label class="form-check-label m-lg-1 mb-0 color-heading" for="attendence_delay<?php echo e($item->id); ?>" style="color: rgb(158, 108, 0)">
                                                        Delay
                                                    </label>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <a href="<?php echo e(route('attendance.index')); ?>" class="btn btn-raised mr-2 btn-default waves-effect">Back</a>

                        <button class="btn btn-raised btn-primary waves-effect" type="submit">SUBMIT</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script>
        $(document).ready(function () {
            $('.attendence-checkbox, .attendence-absent-checkbox, .attendence-delay-checkbox').change(function () {
                var rowId = $(this).data('row-id');
                $('.attendence-checkbox[data-row-id="' + rowId + '"]').not(this).prop('checked', false);
                $('.attendence-absent-checkbox[data-row-id="' + rowId + '"]').not(this).prop('checked', false);
                $('.attendence-delay-checkbox[data-row-id="' + rowId + '"]').not(this).prop('checked', false);
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siddiqui/bes.alodrivingschool.com/resources/views/pages/attendance/edit.blade.php ENDPATH**/ ?>