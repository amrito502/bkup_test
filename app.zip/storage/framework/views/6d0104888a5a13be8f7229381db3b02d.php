<div class="page-loader-wrapper">
    <div class="loader">
        <div class="line"></div>
		<div class="line"></div>
		<div class="line"></div>
        <p>Please wait...</p>
        <div class="m-t-30"><img src="<?php echo e(asset('assets/images/logo.png')); ?>" width="48" height="48" alt="Nexa"></div>
    </div>
</div>
<?php /**PATH /home/siddiqui/bes.alodrivingschool.com/resources/views/layouts/include/page_loader.blade.php ENDPATH**/ ?>