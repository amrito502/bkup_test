<?php $__env->startSection('title', 'Edit Role'); ?>
<?php $__env->startSection('description', 'Edit your own role to access the application.'); ?>
<?php $__env->startSection('breadcrumb01', 'Role'); ?>
<?php $__env->startSection('breadcrumb02', 'Edit Role'); ?>
<?php $__env->startSection('app-content'); ?>
    <style>
        .section-card {
            background: #fff;
            min-height: 50px;
            position: relative;
            transition: .5s;
            border-radius: 8px;
            border: none;
            display: flex;
            flex-direction: column;
        }
    </style>

    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="card">
                <div class="header">
                    <h2>Role</h2>
                <div class="body">
                    <form id="form_validation" action="<?php echo e(route('role.update', [$role->id])); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                        <div class="form-group form-float">
                            <div class="form-line">
                                <input type="text" name="name" id="name" value="<?php echo e($role->name); ?>"
                                    class="form-control" placeholder="Role Name" required>
                                <?php if($errors->has('name')): ?>
                                    <span class="text-danger"><i class="fas fa-exclamation-triangle"></i>
                                        <?php echo e($errors->first('name')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <h5>Select Permission</h5>
                        </div>
                        <div class="row text-black">
                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4 mb-2">
                                    <div class="form-check mb-0 d-flex align-items-center">
                                        <input class="form-check-input" type="checkbox" name="permissions[]"
                                            id="permission<?php echo e($permission->id); ?>" value="<?php echo e($permission->id); ?>" <?php if(in_array($permission->id, $selected_permissions)): ?> checked <?php endif; ?>>
                                        <label class="form-check-label m-lg-1 mb-0 color-heading"
                                            for="permission<?php echo e($permission->id); ?>"><?php echo e(ucwords(str_ireplace('_', ' ', $permission->name))); ?>

                                        </label>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php if($errors->has('permissions')): ?>
                            <span class="text-danger"><i class="fas fa-exclamation-triangle"></i>
                                <?php echo e($errors->first('permissions')); ?></span>
                        <?php endif; ?>
                        <a href="<?php echo e(route('role.index')); ?>" class="btn btn-raised btn-default waves-effect">Back</a>
                        <button class="btn btn-raised btn-primary waves-effect" type="submit">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siddiqui/bes.alodrivingschool.com/resources/views/pages/role/edit.blade.php ENDPATH**/ ?>