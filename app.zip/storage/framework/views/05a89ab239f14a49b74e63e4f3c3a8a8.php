<?php $__env->startSection('title', 'Teacher List'); ?>
<?php $__env->startSection('description', 'Teacher list'); ?>
<?php $__env->startSection('breadcrumb01', 'Teacher'); ?>
<?php $__env->startSection('breadcrumb02', 'Teacher list'); ?>
<?php $__env->startSection('app-content'); ?>
    <style>
        .header-flex {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
    </style>
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="card">
                <div class="header header-flex">
                    <h2>Teacher List</h2>
                    <a href="<?php echo e(route('instructor.create')); ?>" class="btn btn-success btn-sm ml-auto"><i
                            class="zmdi zmdi-plus"></i>
                        Teacher Add</a>
                </div>
                <div class="body table-responsive">

                    <?php if($instructors->count() > 0): ?>

                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Address</th>
                                <th>Phone</th>
                                
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $instructors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($key + 1); ?></th>
                                    <td> <?php echo e($users->first_name); ?> <?php echo e($users->last_name); ?></td>
                                    <td> <?php echo e($users->user->email); ?></td>
                                    <td> <?php echo e($users->address); ?></td>
                                    <td> <?php echo e($users->phone_number); ?></td>
                                    
                                    <td>
                                        <div class="action__buttons">
                                            <a href="<?php echo e(route('instructor.edit', [$users->uuid])); ?>" class="badge badge-info mr-2">
                                                <i class="zmdi zmdi-edit"></i>
                                                
                                            </a>
                                            <a class="badge badge-danger delete"
                                                onclick="return confirm('Are you sure? You want to delete')"
                                                href="<?php echo e(route('instructor.delete', $users->uuid)); ?>">
                                                
                                                <i class="fa fa-trash"></i>
                                                </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <?php else: ?>
                        <div class="alert alert-warning text-center"> <i class="zmdi zmdi-alert-triangle"></i> No Data Found</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>















<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siddiqui/bes.alodrivingschool.com/resources/views/pages/instructor/index.blade.php ENDPATH**/ ?>