<?php $__env->startSection('title', 'Login | UMMUN Model Academy'); ?>

<?php $__env->startSection('auth-content'); ?>

 <style>
    body {
      margin: 0;
      padding: 0;
    }
    .full-page {
      background-image: url(asssts/images/orange_loginbg.jpg);
      background-repeat: no-repeat;
      background-position: center center;
      background-attachment: fixed;
      background-size: cover;
      height: 100vh;
    }
  </style>


<div class="theme-orange full-page" >
    <div class="authentication">
        <div class="card">
            <div class="body">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="mb-2">
                            <img src="<?php echo e(url ('assets/images/logo.png')); ?>" width="100" alt="">
                        </div>
                        <form method="POST" action="<?php echo e(route('login')); ?>" class="col-lg-12" >
                        <?php echo csrf_field(); ?>
                            <h5 class="title">LOGIN</h5>
                            <div class="form-group form-float">
                                <div class="form-line">
                                    <label class="form-label">Email</label>
                                    <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control email" required>

                                </div>
                                <?php if($errors->has('email')): ?>
                                    <span class="text-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo e($errors->first('email')); ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group form-float passwordField">
                                <div class="form-line">
                                    <label class="form-label">Password</label>
                                    <input class="form-control password" name="password" value="<?php echo e(old('password')); ?>" type="password" required>

                                    <span class="showPass"><i class="fa fa-eye"></i></span>

                                    <?php if($errors->has('password')): ?>
                                        <span class="text-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo e($errors->first('password')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="text-left mb-2">
                                <input type="checkbox" name="rememberme" id="rememberme" class="filled-in chk-col-cyan">
                                <label for="rememberme">Remember Me</label>
                            </div>

                            <div class="text-left">
                                <button type="submit" class="btn btn-raised btn-success waves-effect" style="width: 100%;">SIGN IN</button>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siddiqui/bes.alodrivingschool.com/resources/views/auth/login.blade.php ENDPATH**/ ?>