<?php $__env->startSection('title', 'Student Edit'); ?>
<?php $__env->startSection('description', 'Student Edit'); ?>
<?php $__env->startSection('breadcrumb01', 'Student'); ?>
<?php $__env->startSection('breadcrumb02', 'Student Edit'); ?>
<?php $__env->startSection('app-content'); ?>

    <style>
        .header-flex {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
    </style>
    <!-- Input Group -->
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="card">
                <div class="header">
                    <h2> Student Edit </h2>
                    <ul class="header-dropdown m-r--5">
                        <li class="dropdown"> <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown"
                                role="button" aria-haspopup="true" aria-expanded="false"> <i
                                    class="zmdi zmdi-more-vert"></i> </a>
                            <ul class="dropdown-menu pull-right">
                                <li><a href="javascript:void(0);">Action</a></li>
                                <li><a href="javascript:void(0);">Another action</a></li>
                                <li><a href="javascript:void(0);">Something else here</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>

                <div class="body">
                    <form id="form_validation" action="<?php echo e(route('student.update', $student->uuid)); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row clearfix">
                            <div class="col-lg-4 col-md-6">
                                <div class="form-group">
                                    <div class="form-line">
                                    <input type="text" name="first_name" value="<?php echo e($student->first_name); ?>" placeholder="First name" class="form-control" required>
                                        <?php if($errors->has('first_name')): ?>
                                          <span class="text-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo e($errors->first('first_name')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="last_name" value="<?php echo e($student->last_name); ?>" placeholder="Last name" class="form-control" required>
                                        <?php if($errors->has('last_name')): ?>
                                            <span class="text-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo e($errors->first('last_name')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-6">
                                <div class="form-group">
                                    <div class="form-line">
                                        <select  name="gender" id="gender" class="form-control show-tick" required>
                                            <option value="">Select option</option>
                                            <option value="Boy" <?php echo e($student->gender == 'Boy' ? 'selected' : ''); ?> >Boy</option>
                                            <option value="Girl" <?php echo e($student->gender == 'Girl' ? 'selected' : ''); ?> >Girl</option>

                                        </select>
                                        <?php if($errors->has('gender')): ?>
                                            <span class="text-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo e($errors->first('gender')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="email" name="email" value="<?php echo e($user->email); ?>" placeholder="Email" class="form-control" required>
                                        <?php if($errors->has('email')): ?>
                                            <span class="text-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo e($errors->first('email')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-lg-4 col-md-6">
                                <div class="form-group">
                                    <div class="form-line">
                                    <input type="text" name="phone_number" value="<?php echo e($user->phone_number); ?>" placeholder="SMS Phone number" class="form-control">
                                    <?php if($errors->has('phone_number')): ?>
                                        <span class="text-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo e($errors->first('phone_number')); ?></span>
                                    <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="gurdian_phone_number" value="<?php echo e($student->gurdian_phone_number); ?>"
                                            placeholder="Gurdian Phone number" class="form-control" required>
                                        <?php if($errors->has('gurdian_phone_number')): ?>
                                            <span class="text-danger"><i class="fas fa-exclamation-triangle"></i>
                                                <?php echo e($errors->first('gurdian_phone_number')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6">
                                <div class="form-group">
                                    <div class="form-line">
                                    <input type="text" name="address" value="<?php echo e($user->address); ?>" placeholder="Address" class="form-control"
                                           required>
                                    <?php if($errors->has('address')): ?>
                                        <span class="text-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo e($errors->first('address')); ?></span>
                                    <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-6">
                                <div class="form-group">
                                    <div class="form-line">
                                        <!-- <small>Asign role</small> -->

                                        <select  name="class_id" id="class_id" class="form-control show-tick" required>
                                            <option value="<?php echo e($student->assign->studentClass->id); ?>"><?php echo e($student->assign->studentClass->name); ?></option>
                                         <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($data->id); ?>" <?php echo e(old('name') == $data->name ? 'selected' : ''); ?>> <?php echo e($data->name); ?></option>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                         <?php if($errors->has('name')): ?>
                                            <span class="text-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo e($errors->first('name')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-6">
                                <div class="form-group">
                                    <div class="form-line">
                                        <!-- <small>Asign role</small> -->
                                        <select  name="section_id" id="section_id" class="form-control show-tick" required>
                                            <option value="<?php echo e($student->assign->section->id); ?>"><?php echo e($student->assign->section->name); ?></option>
                                            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($data->id); ?>" <?php echo e(old('name') == $data->name ? 'selected' : ''); ?>> <?php echo e($data->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                           </select>
                                            <?php if($errors->has('name')): ?>
                                               <span class="text-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo e($errors->first('name')); ?></span>
                                           <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-6">
                                <div class="form-group">
                                    <div class="form-line">
                                        <!-- <small>Asign role</small> -->
                                        <select name="shift" id="shift" class="form-control show-tick" required>
                                            <option value="">Select Shift</option>
                                            <option value="Morning" <?php echo e($student->assign->shift == 'Morning' ? 'selected' : ''); ?>>Morning
                                            </option>
                                            <option value="Day" <?php echo e($student->assign->shift == 'Day' ? 'selected' : ''); ?>>Day
                                            </option>
                                        </select>
                                        <?php if($errors->has('shift')): ?>
                                            <span class="text-danger"><i class="fas fa-exclamation-triangle"></i>
                                                <?php echo e($errors->first('shift')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>



                        </div>
                        <br/>
                        <a href="<?php echo e(route('student.index')); ?>" class="btn btn-raised btn-default waves-effect">Back</a>
                        <button class="btn btn-raised btn-primary waves-effect" type="submit">Summit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- #END# Input Group -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/custom/image-preview.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('admin/js/custom/image-preview.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/custom/admin-profile.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siddiqui/bes.alodrivingschool.com/resources/views/pages/student/edit.blade.php ENDPATH**/ ?>