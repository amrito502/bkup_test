<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\SmsHistory;
use App\Models\StudentClass;
use App\Traits\General;
use App\Models\Student;
use App\Models\StudentAttendance;


class SmsController extends Controller
{
    use General;

    public function index()
    {
        $data['classes'] = StudentClass::orderBy('id', 'ASC')->get();

        return view('send_sms', $data);
    }

    public function ShowAllsms( Request $request){

        // $data['sms_history'] = SmsHistory::orderBy('id', 'DESC')->get();

        // return view('sms_history', $data);

        $query = SmsHistory::orderBy('id', 'DESC');

        // Apply filters based on request parameters
        if ($request->has('status')) {
            $query->where('status', $request->input('status'));
        }
        if ($request->has('sender')) {
            $query->where('sender', 'like', '%' . $request->input('sender') . '%');
        }
        if ($request->has('date_from') && $request->has('date_to')) {
            $query->whereBetween('created_at', [$request->input('date_from'), $request->input('date_to')]);
        }

        // Paginate the results
        $data['sms_history'] = $query->paginate(50);

        // Return the view with data
        return view('sms_history', $data);
    }

    public function sendStudentSms(Request $request)
    {
        // $request->validate([
        //     'to' => 'required|string',
        //     'message' => 'required|string'
        // ]);

        //Get all students

        // dd($request->all());

        $class = $request->class_id;
        $section = $request->section_id;
        $shift = $request->shift;

        $students = Student::orderBy('user_id', 'DESC')
            ->whereHas('assign', function ($query) use ( $class  , $section, $shift) {
                $query->where('student_class_id', $class)
                    ->where('section_id', $section)
                    ->where('shift', $shift);
            })
            ->with('assign')
            ->get();

        //dd($students);

        foreach ($students as $student) {
            $to = "88" . $student->phone_number;
            $messageBody = $request->message;
            $studentId = $student->user_id;
            $class_name = $student->assign->studentClass->name;
            $studentName = $student->first_name . ' ' . $student->last_name;

            $this->sendSms($to, $messageBody, $studentId, $class_name, $studentName);

        }

        //return response()->json(['marks' => $students]);

        $this->showToastrMessage('success', 'SMS sent successfully');

        return redirect()->back();
    }


    public function sendSms($to, $messageBody, $studentId, $className, $studentName)
    {
        $headers = array(
            "Content-type: application/json",
        );

        $params = array(
            'user' => 'ummunintschool@gmail.com',
            'password' => 'msr46096',
            'from' => 'UMMUN',
            'to' => $to,
            'text' => $messageBody
        );

        $queryString = http_build_query($params);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://panel.smsbangladesh.com/api?$queryString");
        curl_setopt($ch, CURLOPT_HTTPGET, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $resultData = curl_exec($ch);
        $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        $resultDecode = json_decode($resultData);

        // Log SMS history to database
        SmsHistory::create([
            'to' => $to,
            'student_id' => $studentId,
            'student_name' => $studentName,
            'class_name' => $className,
            'message' => $messageBody,
            'status_code' => $statusCode,
            'response' => $resultData
        ]);

        return true;

    }

    public function SendAttendaceSms(Request $request){
        // Retrieve parameters
        $class_id = $request->input('classId');
        $section_id = $request->input('SectionId');
        $shift = $request->input('shift');

        $date_time = \Carbon\Carbon::now()->format('d-m-Y');

        $allAbsentStudents = StudentAttendance::where([
            ['class_id', $class_id],
            ['section_id', $section_id],
            ['shift', $shift],
            ['date', $date_time],
        ])->where('attent', 0)->with('students', 'studentClass')->get();

        // $smsArray = [];

        foreach ($allAbsentStudents as $allAbsentStudent) {

            $studentId = $allAbsentStudent->students->user_id;
            $to = "88" . $allAbsentStudent->students->phone_number;
            $date = $allAbsentStudent->date;

            $student_name = $allAbsentStudent->students->first_name . ' ' . $allAbsentStudent->students->last_name;

            $class_name = $allAbsentStudent->studentClass->name;

            $messageBody = "Dear Guardian, $student_name is absent today, $date . @ Ummun INT School.";

            // $smsArray[] = array(
            //     "to" => "88" . $allAbsentStudent->students->phone_number,
            //     "name" => $allAbsentStudent->students->first_name . ' ' . $allAbsentStudent->students->last_name,
            //     "class" => $allAbsentStudent->studentClass->name,
            //     "date" => $allAbsentStudent->date,
            //     "messagebody" => "Dear Guardian, $student_name is absent today, $date. @ Ummun INT School.",
            // );

            $this->sendSms($to, $messageBody, $studentId, $class_name, $student_name);
        }

        // Your logic here
        return response()->json(['message' => 'SMS Sent Successfully!', 'allAbsentstudents' => $messageBody]);
    }
}
